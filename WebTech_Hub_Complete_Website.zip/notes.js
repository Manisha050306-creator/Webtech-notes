const syllabusUnits = [
  {
    "title": "Internet Foundations",
    "summary": "History of the Internet, World Wide Web, HTTP, SMTP, POP3, MIME, IMAP, DNS, web browsers and web servers",
    "topics": [
      {
        "title": "History of the Internet",
        "content": "The Internet is a worldwide network of interconnected computer networks that communicate using the TCP/IP protocol suite. Its roots lie in ARPANET, a research network developed in the late 1960s. Packet switching allowed information to travel in small packets through different routes. TCP/IP became the common networking standard in 1983, enabling different networks to interconnect. The Web was later proposed by Tim Berners-Lee in 1989 and introduced tools such as URLs, HTTP and HTML.",
        "key": "Internet = infrastructure connecting networks; World Wide Web = a service that runs on the Internet. Other Internet services include email, file transfer and online gaming.",
        "example": "Example: Opening a website uses the Internet to carry HTTP requests and responses between your browser and a web server."
      },
      {
        "title": "World Wide Web and HTML",
        "content": "The World Wide Web is a collection of linked documents and resources identified by URLs and accessed through browsers. HTML (HyperText Markup Language) describes the structure and meaning of a web page using elements and tags. A basic HTML document contains <!DOCTYPE html>, html, head and body elements. Head contains metadata and the page title; body contains visible content.",
        "key": "HTML is a markup language, not a programming language. Common elements include headings (h1–h6), paragraphs (p), links (a), images (img), lists (ul/ol/li) and semantic elements such as header, nav, main and footer.",
        "example": "Example: <code>&lt;a href=\"about.html\"&gt;About us&lt;/a&gt;</code> creates a hyperlink to another page."
      },
      {
        "title": "HTTP protocol",
        "content": "HTTP (Hypertext Transfer Protocol) is an application-layer request-response protocol used by browsers and servers. A client sends a request containing a method, path, headers and sometimes a body. The server returns a status code, headers and response body. Common methods are GET (retrieve), POST (submit/create), PUT (replace), PATCH (partially update) and DELETE (remove). Status code groups: 1xx informational, 2xx success, 3xx redirection, 4xx client error and 5xx server error. HTTPS is HTTP protected by TLS encryption.",
        "key": "HTTP is stateless: each request is independent. Cookies, sessions and tokens can maintain user state. GET should normally be safe and idempotent; POST is commonly used for submissions.",
        "example": "Example: GET /products asks the server for a product list; 200 means success, 404 means the resource was not found."
      },
      {
        "title": "SMTP, POP3, MIME and IMAP",
        "content": "SMTP (Simple Mail Transfer Protocol) sends outgoing email from a client to a mail server and between mail servers. POP3 (Post Office Protocol version 3) downloads messages to a device, often for offline reading; depending on settings, it may remove them from the server. IMAP (Internet Message Access Protocol) keeps mail on the server and synchronizes folders, read status and messages across devices. MIME (Multipurpose Internet Mail Extensions) extends email formats so messages can carry attachments, images, audio, HTML and non-ASCII text using content-type and transfer-encoding headers.",
        "key": "SMTP is mainly for sending; POP3 and IMAP are for receiving/accessing; MIME describes the content format and attachments.",
        "example": "Example: A phone email app may use SMTP to send and IMAP to synchronize the inbox on both phone and laptop."
      },
      {
        "title": "Domain Name System (DNS)",
        "content": "DNS is a distributed, hierarchical naming system that translates human-readable domain names into IP addresses. When a user enters a domain, a resolver checks its cache and may query DNS servers. The hierarchy includes root servers, top-level domain servers (such as .com) and authoritative name servers. Common record types: A (IPv4), AAAA (IPv6), CNAME (alias), MX (mail server), NS (name server) and TXT (text/verification).",
        "key": "DNS caching uses TTL (time to live) to reduce repeated lookups. DNS makes the web easier to use because people remember names more easily than numeric IP addresses.",
        "example": "Example: DNS resolves example.com to an IP address so the browser can connect to the correct server."
      },
      {
        "title": "Web browsers and web servers",
        "content": "A web browser is client software that requests, interprets and displays web resources. It parses HTML into the DOM, parses CSS into style information, executes JavaScript and lays out/paints the page. A web server is software (and the computer running it) that accepts requests and returns web pages, files or API responses. Servers may serve static files directly or run application code and query databases.",
        "key": "Browser examples include Chrome, Firefox, Safari and Edge. Server software examples include Apache HTTP Server, Nginx and Microsoft IIS. Browser developer tools help inspect HTML, CSS, JavaScript, network requests and errors.",
        "example": "Flow: user enters URL → DNS lookup → browser connects → HTTP request → server response → browser renders page."
      }
    ]
  },
  {
    "title": "HTML, CSS, JavaScript and XML",
    "summary": "Lists, tables, images, forms, frames, DHTML, CSS, DTD, XML schemas, object models, presenting XML, DOM and SAX",
    "topics": [
      {
        "title": "HTML lists, tables and images",
        "content": "HTML lists organize related items. An unordered list uses ul and li; an ordered list uses ol and li; a description list uses dl, dt and dd. Tables represent tabular data with table, caption, thead, tbody, tr, th and td. Use headers to identify columns/rows and do not use tables merely for page layout. Images are embedded with img using src and meaningful alt text. Width and height help reserve layout space.",
        "key": "Use semantic markup for accessibility. A useful alt attribute describes the image's purpose; decorative images can use alt=\"\".",
        "example": "Example: <code>&lt;ol&gt;&lt;li&gt;Plan&lt;/li&gt;&lt;li&gt;Build&lt;/li&gt;&lt;/ol&gt;</code> creates a numbered list."
      },
      {
        "title": "HTML forms",
        "content": "Forms collect user input and submit it to a server. The form element commonly uses action (destination) and method (GET or POST). Controls include input, label, textarea, select, option, button and fieldset. Input types include text, email, password, number, date, radio and checkbox. Labels improve accessibility; required, min, max, pattern and type provide browser-side validation.",
        "key": "Client-side validation improves usability but is not a security boundary. Always validate and sanitize submitted data on the server too. Use POST for sensitive or state-changing submissions and HTTPS to protect data in transit.",
        "example": "Example: an email field with type=\"email\" asks the browser to check that the value resembles an email address."
      },
      {
        "title": "Frames and modern alternatives",
        "content": "Traditional HTML frames divided a browser window into multiple independently loaded documents using frameset, frame or iframe. Frames and framesets are obsolete in modern HTML because they create navigation, accessibility, bookmarking and responsive-design problems. iframe remains available for embedding another page, such as a map or video, with careful attention to permissions, title and sandbox attributes.",
        "key": "Prefer CSS layouts (Flexbox/Grid) and normal document navigation instead of framesets. Use iframe only when embedding a separate document is genuinely needed.",
        "example": "Example: an embedded video player may be placed in an iframe with a descriptive title."
      },
      {
        "title": "CSS and CSS document structure",
        "content": "CSS (Cascading Style Sheets) controls presentation: colors, typography, spacing, layout, borders and responsive behavior. Rules consist of selectors and declaration blocks. CSS can be inline, internal in a style element or external in a .css file; external stylesheets are easiest to maintain across pages. The cascade resolves competing rules using origin, importance, specificity and source order. The box model consists of content, padding, border and margin. Media queries adapt styles to screen size.",
        "key": "Selectors include element (p), class (.card), ID (#header), attribute and pseudo-classes (:hover). box-sizing:border-box makes declared dimensions include padding and border.",
        "example": "Example: <code>.card { padding: 16px; border-radius: 12px; }</code> styles every element with class card."
      },
      {
        "title": "Dynamic HTML (DHTML) with JavaScript",
        "content": "DHTML is a broad term for web pages whose content or appearance changes after loading through a combination of HTML, CSS, JavaScript and the DOM. JavaScript can respond to events, validate forms, update text, change classes and create or remove elements without a full page reload. Modern development usually describes these capabilities as DOM scripting rather than a separate DHTML language.",
        "key": "Typical steps: select an element, listen for an event, update its content/style/state. Keep behavior in JavaScript, structure in HTML and presentation in CSS.",
        "example": "Example: clicking a button can change an element's text using element.textContent."
      },
      {
        "title": "XML and DTD",
        "content": "XML (Extensible Markup Language) is a text-based format for representing structured, self-describing data. Unlike HTML, XML lets authors define their own tags. XML must be well-formed: one root element, properly nested tags, quoted attribute values and case-sensitive matching tags. A DTD (Document Type Definition) describes permitted elements, attributes and structure. DTD declarations can be internal or external.",
        "key": "Well-formed means syntactically correct; valid means it also conforms to a DTD or schema. XML is commonly used for configuration, document exchange and legacy integrations.",
        "example": "Example: <code>&lt;student&gt;&lt;name&gt;Asha&lt;/name&gt;&lt;semester&gt;5&lt;/semester&gt;&lt;/student&gt;</code> represents a student record."
      },
      {
        "title": "XML Schema (XSD)",
        "content": "XML Schema Definition (XSD) describes the structure, elements, attributes, data types, ordering, occurrence limits and constraints of an XML document. Compared with DTD, XSD supports namespaces and rich built-in types such as string, integer, date and decimal, plus custom simple and complex types. Validation checks whether an XML document follows the declared rules.",
        "key": "minOccurs and maxOccurs control how often an element may appear. type controls its data type. XSD is itself written in XML syntax.",
        "example": "Example: an XSD can require a student element to contain a name string and a roll number integer."
      },
      {
        "title": "Object models: DOM",
        "content": "The Document Object Model (DOM) represents an HTML or XML document as a tree of objects/nodes. Elements, attributes and text are represented as nodes that programs can inspect and modify. JavaScript uses DOM APIs to select nodes, read or change content, update attributes, add/remove elements and handle events. The DOM provides a platform-neutral programming interface.",
        "key": "DOM is convenient when a program needs tree navigation or modification, but parsing a very large document into a full tree can use substantial memory.",
        "example": "Example: document.querySelector('#heading').textContent = 'Welcome'; changes the text of an element."
      },
      {
        "title": "Presenting XML and XML processors: DOM and SAX",
        "content": "XML can be displayed using CSS, transformed using XSLT, or processed by application code. An XML processor reads XML and checks its syntax and, when configured, validation rules. DOM parses the complete document into a tree, allowing random navigation and editing. SAX (Simple API for XML) is event-driven: the parser reports events such as start-element, text and end-element while reading sequentially.",
        "key": "DOM: easier navigation/editing, higher memory use. SAX: low memory and suitable for large/streaming XML, but forward-only and less convenient for arbitrary navigation.",
        "example": "Example: use DOM to edit a small XML configuration file; use SAX-style parsing to process a very large XML feed."
      }
    ]
  },
  {
    "title": "Web Services and AJAX",
    "summary": "Introduction to Web Services, UDDI, SOAP, WSDL, architecture, development/deployment, AJAX and CORBA",
    "topics": [
      {
        "title": "Introduction to Web Services",
        "content": "A web service is a software component that exposes functionality or data over a network through a defined interface. It allows applications built with different languages or platforms to communicate. Common styles include SOAP-based services and RESTful APIs. A service typically receives a request, processes it and returns a response, often in XML or JSON.",
        "key": "Benefits include interoperability, reuse, loose coupling and integration between systems. Security, authentication, versioning and error handling must be designed carefully.",
        "example": "Example: a college website can call a payment service to verify a transaction without implementing banking infrastructure itself."
      },
      {
        "title": "Web service architecture",
        "content": "A traditional service architecture includes a service provider, service requester/consumer and sometimes a service registry. The provider publishes a service description; the consumer discovers or obtains the description and invokes the service. In SOAP-oriented architecture, XML messages are commonly transported over HTTP or other protocols. Modern systems may use API gateways, authentication services, load balancers and monitoring.",
        "key": "The registry/discovery model is conceptual; many modern APIs are documented and discovered through portals or OpenAPI documents rather than public registries.",
        "example": "Flow: provider publishes interface → consumer learns endpoint and operations → consumer sends request → provider returns response."
      },
      {
        "title": "UDDI",
        "content": "UDDI (Universal Description, Discovery and Integration) is a registry standard designed to publish and discover web services. It organizes information about businesses, service descriptions and technical binding details. A UDDI registry can help a consumer locate a provider and learn where/how a service can be accessed.",
        "key": "UDDI is associated with the classic SOAP web-service stack. Public UDDI registries are not central to most modern web development, but the concept of service discovery remains important.",
        "example": "Example: a directory lists a currency-conversion service and its technical endpoint so a client can locate it."
      },
      {
        "title": "SOAP",
        "content": "SOAP (Simple Object Access Protocol) is a messaging protocol for exchanging structured information, commonly encoded in XML. A SOAP message has an Envelope; it may contain a Header for metadata and a Body for the main message. A Fault element carries error information. SOAP can work with different transport protocols, although HTTP is common. It supports formal contracts and extensions for security and reliability.",
        "key": "SOAP is strongly structured and contract-oriented. It can be verbose compared with JSON-based REST APIs. SOAP should not be confused with a transport protocol.",
        "example": "Example: a SOAP request may contain an XML body asking a service to retrieve a student's result."
      },
      {
        "title": "WSDL",
        "content": "WSDL (Web Services Description Language) is an XML-based description of a web service. It describes available operations, messages, data types, communication bindings and service endpoints. A client can use the WSDL contract to understand how to construct requests and interpret responses. WSDL 1.1 is widely encountered in traditional SOAP systems.",
        "key": "WSDL answers what operations exist, what data they exchange and how/where to call them. It is a service contract, not the service implementation itself.",
        "example": "Example: a WSDL document may define a getResult operation that accepts a roll number and returns marks."
      },
      {
        "title": "Developing and deploying web services",
        "content": "A typical workflow is: identify service operations, define request/response data, implement business logic, expose endpoints, secure them, test requests and deploy to a server or cloud platform. SOAP services may use WSDL and XML schemas; REST APIs commonly use HTTP methods and JSON. Deployment includes configuration, secrets management, logging, monitoring, scaling and version control.",
        "key": "Test normal requests, invalid input, authentication failures, timeouts and server errors. Never hard-code production passwords or API keys in public source code.",
        "example": "Example: deploy a student-result API behind HTTPS and require an authenticated client before returning private results."
      },
      {
        "title": "AJAX and improving page performance",
        "content": "AJAX (Asynchronous JavaScript and XML) is a technique for exchanging data with a server asynchronously and updating part of a page without reloading the entire document. Despite its name, JSON is now more common than XML. The browser can use fetch() or XMLHttpRequest to make requests, then update the DOM when data arrives. Performance can improve because only needed data is transferred and only part of the interface changes.",
        "key": "AJAX does not automatically make every page faster. Optimize payload size, caching, request count, server response time and loading states. Handle errors and cancellation.",
        "example": "Example: a search suggestion box requests matching terms while the user types, then displays suggestions without reloading the page."
      },
      {
        "title": "Programming in AJAX",
        "content": "The basic pattern is: listen for an event, send an asynchronous request, check the response, convert the data and update the page. With fetch(), a promise is returned. Check response.ok because HTTP errors do not always reject the promise. Use try/catch for network or parsing errors and show a loading or error state.",
        "key": "Debounce frequent events such as keystrokes to avoid sending too many requests. Do not insert untrusted server text with innerHTML; use textContent or sanitize trusted HTML.",
        "example": "Example: fetch('/api/items').then(r => r.json()).then(data => renderItems(data)).catch(showError)."
      },
      {
        "title": "CORBA",
        "content": "CORBA (Common Object Request Broker Architecture) is an OMG standard that enables distributed objects written in different programming languages and running on different systems to communicate. An Object Request Broker (ORB) locates objects, routes requests and returns results. Interfaces are described using IDL (Interface Definition Language); an IDL compiler generates language-specific stubs and skeletons.",
        "key": "CORBA supports language and platform interoperability but can add infrastructure complexity. It is a distributed-object middleware architecture, not a web protocol.",
        "example": "Example: a Java client can invoke an operation on a remote C++ object through an ORB using a shared IDL interface."
      }
    ]
  },
  {
    "title": "Web 2.0 and Web 3.0",
    "summary": "Interactive/social web, blogs, wikis, social networking, AJAX, RSS, Ruby on Rails, APIs, semantic web, widgets, mashups, RDF, information systems, search engines, recommenders, blockchain, edge computing and dark mode",
    "topics": [
      {
        "title": "Web 2.0: interactive and social web",
        "content": "Web 2.0 describes the shift from mostly static, read-only pages to participatory services where users create, share, comment on and collaborate around content. It is a broad evolution rather than a single technology or formal version of HTML. Blogs, wikis, social networks, media-sharing platforms and collaborative applications are common examples.",
        "key": "Important ideas: user-generated content, participation, collaboration, rich browser interfaces, network effects and continuously updated services. Risks include misinformation, privacy loss, harassment and platform dependence.",
        "example": "Example: users collaboratively edit a wiki page rather than only reading a publisher's fixed page."
      },
      {
        "title": "Blogs, wikis and social networking sites",
        "content": "A blog is a regularly updated website where posts are usually shown in reverse chronological order and may allow comments. A wiki is a collaborative collection of pages that users can create and edit, often with revision history. Social networking sites let people create profiles, connect with others, share content and communicate. These platforms depend on user accounts, databases, moderation and recommendation systems.",
        "key": "Blogs emphasize publishing; wikis emphasize collaborative knowledge editing; social networks emphasize relationships and interaction. Their functions can overlap.",
        "example": "Example: a class blog posts announcements, a wiki documents project instructions and a social group coordinates student activities."
      },
      {
        "title": "Technologies behind Web 2.0 and AJAX",
        "content": "Web 2.0 applications commonly combine HTML, CSS, JavaScript, server-side code, databases, APIs and asynchronous requests. AJAX allows portions of a page to refresh with server data. DOM manipulation updates the interface; JSON is a common data format. Authentication, caching, content delivery networks and scalable databases support larger services.",
        "key": "AJAX is one enabling technique, not the definition of Web 2.0. Accessibility, progressive enhancement and secure API design remain important.",
        "example": "Example: a social feed can request the next page of posts when the user scrolls near the bottom."
      },
      {
        "title": "RSS",
        "content": "RSS (Really Simple Syndication) is a web feed format, usually XML, that publishes updates from a site in a machine-readable way. Feed readers check the feed and display new articles or episodes without users visiting each site manually. An RSS feed commonly contains channel metadata and items with titles, links, dates and summaries.",
        "key": "RSS supports subscription-based updates and is useful for blogs, podcasts and news. Atom is another feed format.",
        "example": "Example: subscribing to a university news RSS feed lets a reader see newly published notices in one place."
      },
      {
        "title": "Ruby on Rails",
        "content": "Ruby on Rails is an open-source web application framework written in Ruby. It follows convention over configuration and emphasizes developer productivity. Rails commonly uses the Model-View-Controller (MVC) pattern: models manage data/business rules, views present output and controllers handle requests. Active Record provides object-relational mapping for database operations.",
        "key": "Rails includes routing, migrations, validations, templates and testing tools. Security still requires careful authorization, input validation and secure configuration.",
        "example": "Example: a Rails application can define a Student model, a controller for student requests and views that render student details."
      },
      {
        "title": "Open APIs",
        "content": "An open API is an interface made available for external developers to use under published rules, documentation and access conditions. APIs allow applications to exchange data or invoke functions. HTTP APIs often use endpoints, methods, status codes, JSON, authentication tokens and rate limits. Open does not necessarily mean unlimited or free; terms and permissions still apply.",
        "key": "Good API design includes consistent naming, versioning, clear errors, documentation, authentication and usage limits. Protect API keys and personal data.",
        "example": "Example: a weather application may call a documented weather API to display forecast information."
      },
      {
        "title": "Web 3.0 and Semantic Web",
        "content": "Web 3.0 is used in different ways. In the semantic-web sense, it refers to making web data more structured and machine-understandable so software can interpret relationships and meaning. In blockchain discussions, Web3 often refers to decentralized applications and user-controlled digital assets. These are related conversations but not identical definitions.",
        "key": "Semantic technologies include RDF, ontologies, URIs and query languages such as SPARQL. Blockchain-based Web3 emphasizes distributed ledgers, wallets and smart contracts.",
        "example": "Example: structured data can express that a person is enrolled in a course, allowing software to reason about that relationship."
      },
      {
        "title": "Widgets and mashups",
        "content": "A widget is a small reusable interface component that displays information or provides a focused function, such as a calendar, weather panel or chat button. A mashup combines data or functionality from multiple sources into one application, often through APIs and embedded components. Good mashups handle attribution, permissions, failures and data freshness.",
        "key": "Widgets are interface building blocks; mashups integrate multiple services or datasets. Both can improve user experience but may introduce third-party privacy and availability dependencies.",
        "example": "Example: a campus dashboard combines a map API, event feed and weather data in one page."
      },
      {
        "title": "RDF (Resource Description Framework)",
        "content": "RDF is a framework for representing information as triples: subject, predicate and object. Each triple expresses a relationship, often using URIs to identify resources. A set of triples forms a graph. RDF can be serialized in formats such as Turtle, RDF/XML and JSON-LD. It is a foundation for linked data and semantic-web applications.",
        "key": "Example triple: (Manisha, studies, Web Technology). Real RDF uses identifiers and defined vocabularies to make statements machine-processable.",
        "example": "RDF graphs can be queried using SPARQL and combined across datasets when identifiers and vocabularies are compatible."
      },
      {
        "title": "Web-based information systems",
        "content": "A web-based information system uses browser-accessible interfaces, networks, application logic and data storage to collect, process, store and present information. Typical layers include presentation (browser), application/business logic (server) and data (database). Examples include student portals, online banking, inventory systems and e-commerce platforms.",
        "key": "Advantages include centralized updates, broad access and easier integration. Challenges include network dependency, security, privacy, availability and performance.",
        "example": "Example: a student portal lets students view attendance and results while the server retrieves authorized records from a database."
      },
      {
        "title": "Search engines",
        "content": "A search engine discovers and organizes web pages so users can find relevant information. Typical stages are crawling (discovering URLs), indexing (analyzing and storing page information) and ranking/serving (ordering results for a query). Ranking can consider relevance, quality, freshness, usability, location and many other signals. Search engines may also use structured data and language processing.",
        "key": "SEO (search engine optimization) improves discoverability through useful content, accessible structure, descriptive titles, fast pages and crawlable links. No one can guarantee a particular ranking.",
        "example": "Example: a crawler visits a page, the engine indexes its content and later returns it for a relevant search query."
      },
      {
        "title": "Recommender systems",
        "content": "A recommender system predicts which items a user may find useful. Content-based filtering recommends items similar to a user's previous interests. Collaborative filtering uses patterns from many users or item interactions. Hybrid systems combine methods. Recommendations are used in shopping, streaming, news and learning platforms.",
        "key": "Challenges include cold-start problems, sparse data, popularity bias, feedback loops, privacy and filter bubbles. Evaluation can measure relevance, diversity, coverage and user satisfaction.",
        "example": "Example: a learning portal may suggest a database tutorial because the student studied SQL topics recently."
      },
      {
        "title": "Benefits of blockchain",
        "content": "Blockchain is a shared, append-only ledger maintained by a network of participants. Blocks are linked cryptographically, and consensus rules help participants agree on the ledger state. Potential benefits include tamper-evident records, shared visibility, auditability and reduced dependence on one central record keeper. Smart contracts can automate agreed rules.",
        "key": "Blockchain is not automatically faster, cheaper, private or more secure than a conventional database. Consider governance, scalability, energy use, transaction costs, privacy and legal requirements before choosing it.",
        "example": "Example: multiple organizations may share a verifiable record of supply-chain handoffs."
      },
      {
        "title": "Edge computing",
        "content": "Edge computing processes data near the device or location where it is generated instead of sending everything to a distant cloud data center. It can reduce latency, lower bandwidth use and support operation during intermittent connectivity. Edge devices may filter, aggregate or analyze sensor data before forwarding selected information.",
        "key": "Challenges include managing distributed devices, physical security, updates, limited compute resources and data synchronization. Edge and cloud computing usually complement one another.",
        "example": "Example: a factory sensor gateway detects an abnormal machine vibration locally and sends an alert immediately."
      },
      {
        "title": "Dark mode in web development",
        "content": "Dark mode is a user-interface theme that uses dark surfaces and lighter text. It can improve comfort in low-light environments and may reduce power use on some OLED displays. A robust website can support a user-selected theme and the operating system preference using prefers-color-scheme. Maintain sufficient color contrast, visible focus states and readable form controls.",
        "key": "Do not simply invert all colors. Define theme colors as CSS variables and test contrast, images, charts and disabled states in both themes.",
        "example": "Example: CSS can use @media (prefers-color-scheme: dark) to apply a dark color palette."
      }
    ]
  },
  {
    "title": "Web 4.0 and Emerging Technologies",
    "summary": "AI-powered web, personalization, decentralized web, blockchain, IoT, AR/VR, smart web, adaptive interfaces, automation and 5G",
    "topics": [
      {
        "title": "Web 4.0: AI-powered and personalized web",
        "content": "Web 4.0 is a forward-looking term often used for a more intelligent, connected and context-aware web. AI can help understand language, summarize information, generate content, detect patterns and power conversational interfaces. Personalization adapts content or recommendations to user needs, preferences or context. The term does not have one universally agreed technical definition.",
        "key": "Personalization should be transparent and controllable. Systems need consent, privacy protection, bias testing, explainability where appropriate and human oversight for consequential decisions.",
        "example": "Example: an educational website may suggest a revision path based on quiz performance, while allowing the learner to change recommendations."
      },
      {
        "title": "Decentralized Web (DWeb) and blockchain integration",
        "content": "The Decentralized Web aims to reduce reliance on a small number of centralized platforms by distributing storage, identity, hosting or application logic across networks. Blockchain may provide shared state, token-based coordination or smart contracts. Decentralized storage systems can address content by identifiers rather than a single server location.",
        "key": "Decentralization involves trade-offs: user experience, governance, permanence, moderation, scalability, key management and recovery. A blockchain does not automatically decentralize every part of an application.",
        "example": "Example: a decentralized application may use a smart contract for shared transaction rules and decentralized storage for selected content."
      },
      {
        "title": "Internet of Things (IoT) in web development",
        "content": "IoT connects physical devices such as sensors, appliances, vehicles and machines to networks. Web applications can display device status, collect telemetry, send commands and visualize trends. Common building blocks include sensors, embedded controllers, gateways, network protocols, cloud/edge services, APIs and dashboards. MQTT and HTTP are common communication choices.",
        "key": "Security is essential: unique credentials, encrypted communication, firmware updates, access control and network segmentation help protect devices. Collect only data that is needed.",
        "example": "Example: a smart irrigation dashboard reads soil moisture sensors and lets an authorized user adjust watering schedules."
      },
      {
        "title": "Augmented Reality (AR) and Virtual Reality (VR) on the web",
        "content": "AR overlays digital objects or information on the user's view of the real world. VR places the user in a computer-generated immersive environment. Web technologies can deliver 3D content and immersive experiences through browser APIs and frameworks. WebXR is a browser API family designed to support AR and VR experiences on compatible devices.",
        "key": "AR can support product previews, navigation and training; VR can support simulations, tours and learning. Device support, motion comfort, accessibility, performance and privacy must be considered.",
        "example": "Example: a web-based AR furniture preview can place a 3D chair model in a camera view of a room."
      },
      {
        "title": "Smart Web",
        "content": "The Smart Web is a broad idea of web services that use data, connected devices, automation and intelligent processing to respond more helpfully to users. It may combine semantic data, AI, IoT, context awareness and interoperable services. It is a vision rather than one single protocol or standard.",
        "key": "A smart service should make its decisions understandable, protect user data and provide ways to correct inaccurate information. Interoperability and reliable data quality are important.",
        "example": "Example: a smart campus portal could combine room availability, class schedules and energy sensors to recommend available study spaces."
      },
      {
        "title": "Adaptive interfaces",
        "content": "An adaptive interface changes its layout, content or controls according to device size, input method, accessibility settings, user preferences or context. Responsive design commonly uses fluid layouts, flexible images, CSS Grid/Flexbox and media queries. More advanced adaptive interfaces may adjust navigation or content based on user behavior.",
        "key": "Design for a broad range of users first. Respect reduced-motion preferences, keyboard navigation, screen readers and user control. Avoid unexpected changes that make an interface hard to predict.",
        "example": "Example: a navigation bar may collapse into a menu on a narrow phone screen while remaining fully visible on desktop."
      },
      {
        "title": "Web automation",
        "content": "Web automation uses software to perform repetitive browser or web tasks, such as testing forms, checking links, collecting permitted data or completing routine workflows. Tools may control a browser, interact with elements, take screenshots and verify expected results. Automated tests can cover functional, regression and end-to-end behavior.",
        "key": "Use automation only where authorized and respect website terms, robots rules, rate limits and privacy. Keep credentials secure; design tests to be stable and avoid brittle selectors.",
        "example": "Example: an end-to-end test opens a login page, enters test credentials and checks that the dashboard appears."
      },
      {
        "title": "Impact of 5G on web technologies",
        "content": "5G is a generation of mobile network technology designed to provide higher potential data rates, lower latency in suitable conditions, greater capacity and support for many connected devices. These capabilities can improve mobile cloud applications, real-time collaboration, IoT, cloud gaming and AR/VR experiences. Actual performance depends on coverage, spectrum, congestion, device and network configuration.",
        "key": "5G does not remove the need for efficient web design. Applications still need caching, compression, responsive media, graceful fallback and security. Edge computing may work alongside 5G to reduce round-trip delays.",
        "example": "Example: a connected industrial system may use 5G connectivity to transmit sensor data to nearby edge services for rapid analysis."
      }
    ]
  }
];
